-- phpMyAdmin SQL Dump
-- version 4.0.10.10
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 28 2017 г., 09:16
-- Версия сервера: 5.5.45
-- Версия PHP: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `yii_im_1_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `action`
--

CREATE TABLE IF NOT EXISTS `action` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) unsigned NOT NULL DEFAULT '0',
  `short_title` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `teaser` text NOT NULL,
  `body` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `is_main` int(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `action`
--

INSERT INTO `action` (`id`, `cat_id`, `short_title`, `title`, `date`, `teaser`, `body`, `alias`, `weight`, `is_main`, `status`) VALUES
(3, 0, 'Основной материал модуля', 'Основной материал модуля', '', '', '<p>Наши акции</p>\r\n', 'osnovnoy-material-modulya', 0, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zone` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `postcode` varchar(255) NOT NULL,
  `postname` varchar(255) NOT NULL,
  `postlastname` varchar(255) NOT NULL,
  `postphathername` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `address`
--

INSERT INTO `address` (`id`, `user_id`, `title`, `country`, `zone`, `city`, `address`, `postcode`, `postname`, `postlastname`, `postphathername`, `comment`) VALUES
(1, 12, 'Офис', 'Россия', '', 'Новосибирск', 'ул.Линейная 114/2 оф.204', '637000', 'Дмитрий', 'Хлебов', 'Иванович', 'По лестнице на второй этаж и направо и налево.'),
(2, 12, 'Домашний', 'Россия', '', 'Новосибирск', 'ул. Кропоткина 136 кв.220', '637000', 'Дмитрий', 'Хлебов', 'Иванович', '4 подъезд');

-- --------------------------------------------------------

--
-- Структура таблицы `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) unsigned NOT NULL DEFAULT '0',
  `short_title` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `teaser` text NOT NULL,
  `body` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `is_main` int(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Дамп данных таблицы `article`
--

INSERT INTO `article` (`id`, `cat_id`, `short_title`, `title`, `date`, `teaser`, `body`, `alias`, `weight`, `is_main`, `status`) VALUES
(19, 0, 'Основной материал модуля', 'Основной материал модуля', '', '', '<p>Наши статьи</p>\r\n', 'osnovnoy-material-modulya', 0, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `banner`
--

CREATE TABLE IF NOT EXISTS `banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) unsigned NOT NULL DEFAULT '0',
  `text_block1` text NOT NULL,
  `text_block2` text NOT NULL,
  `text_block3` text NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `banner`
--

INSERT INTO `banner` (`id`, `cat_id`, `text_block1`, `text_block2`, `text_block3`, `weight`, `status`) VALUES
(1, 0, '', '', '', 0, 1),
(2, 0, '', '', '', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `created_time` int(11) NOT NULL,
  `updated_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `created_time`, `updated_time`) VALUES
(3, '1', 1489380497, 1490012211),
(4, 'beaf90466b1a4ac318caf07e99208ec5', 1489735421, 1489735421),
(5, '64f46a1b9400ba72547d2485a6a219cd', 1493098432, 1493098484);

-- --------------------------------------------------------

--
-- Структура таблицы `cart_element`
--

CREATE TABLE IF NOT EXISTS `cart_element` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(55) DEFAULT NULL,
  `model` varchar(110) COLLATE utf8_unicode_ci NOT NULL,
  `cart_id` int(11) NOT NULL,
  `item_id` int(55) NOT NULL,
  `count` int(11) NOT NULL,
  `price` decimal(11,2) DEFAULT NULL,
  `hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `options` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `cart_id` (`cart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `cart_element`
--

INSERT INTO `cart_element` (`id`, `parent_id`, `model`, `cart_id`, `item_id`, `count`, `price`, `hash`, `options`) VALUES
(1, NULL, 'app\\modules\\product\\models\\Product', 3, 1, 1, '1090.00', 'fc57fb0b3f7bebd060cdfcd5d25e612c', '{"1":"red","2":"little"}'),
(2, NULL, 'app\\modules\\product\\models\\Product', 5, 1, 1, '1090.00', 'ebc2cd8575d885799276c34cad52d5b3', '[]');

-- --------------------------------------------------------

--
-- Структура таблицы `catalog`
--

CREATE TABLE IF NOT EXISTS `catalog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `short_title` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `teaser` text NOT NULL,
  `body` text NOT NULL,
  `text1` text NOT NULL,
  `text2` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `attach_title` varchar(255) NOT NULL,
  `attach` text NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `in_front` int(1) NOT NULL DEFAULT '0',
  `is_main` int(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=100 ;

--
-- Дамп данных таблицы `catalog`
--

INSERT INTO `catalog` (`id`, `parent_id`, `short_title`, `title`, `teaser`, `body`, `text1`, `text2`, `alias`, `attach_title`, `attach`, `weight`, `in_front`, `is_main`, `status`) VALUES
(89, 0, 'Основной материал модуля', 'Каталог Услуг', '', '', '', '', 'katalog-uslug', 'Возможно, вас также заинтересует', '', 0, 0, 1, 1),
(93, 0, 'Спорт', 'Спорт', '', '', '', '', 'sport', '', '', 0, 1, 0, 1),
(94, 0, 'Для дома', 'Для дома', '', '', '', '', 'dlya-doma', '', '', 0, 1, 0, 1),
(95, 0, 'Для бани', 'Для бани', '', '', '', '', 'dlya-bani', '', '', 0, 1, 0, 1),
(96, 0, 'Для дачи', 'Для дачи', '', '', '', '', 'dlya-dachi', '', '', 0, 1, 0, 1),
(97, 0, 'Для авто', 'Для авто', '', '', '', '', 'dlya-avto', '', '', 0, 1, 0, 1),
(98, 0, 'Анаболики', 'Анаболики', '', '', '', '', 'anaboliki', '', '', 0, 0, 0, 1),
(99, 0, 'Белок', 'Белок', '', '', '', '', 'belok', '', '', 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `catalog_catalog`
--

CREATE TABLE IF NOT EXISTS `catalog_catalog` (
  `parent_id` int(11) unsigned NOT NULL,
  `child_id` int(11) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `catalog_catalog`
--

INSERT INTO `catalog_catalog` (`parent_id`, `child_id`) VALUES
(93, 98),
(98, 99);

-- --------------------------------------------------------

--
-- Структура таблицы `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `bankname` varchar(255) NOT NULL,
  `bik` varchar(255) NOT NULL,
  `inn` varchar(255) NOT NULL,
  `kpp` varchar(255) NOT NULL,
  `rs` varchar(255) NOT NULL,
  `ks` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `company`
--

INSERT INTO `company` (`id`, `user_id`, `company`, `address`, `phone`, `fax`, `email`, `comment`, `bankname`, `bik`, `inn`, `kpp`, `rs`, `ks`) VALUES
(1, 12, 'ООО "Звендурей"', '', '', '', '', 'Тестовая организация', 'Сбербанк России', '345000', '2523523466315', '134862763', '542345246527631425235', '4615373685796935768457');

-- --------------------------------------------------------

--
-- Структура таблицы `emailtemp`
--

CREATE TABLE IF NOT EXISTS `emailtemp` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `act` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Дамп данных таблицы `emailtemp`
--

INSERT INTO `emailtemp` (`id`, `title`, `subject`, `body`, `act`) VALUES
(1, 'Регистрация 1', 'Подтверждение Email при регистрации на [sitename]', '<p>Здравствуйте, [name]!</p>\r\n\r\n<p>Благодарим Вас за регистрацию на нашем сайте!<br />\r\nДля завершения процесса регистрации необходимо перейти по ссылке [link].</p>\r\n\r\n<p>[sitename]</p>\r\n', 1),
(3, 'Восстановление пароля', 'Восстановление пароля на [sitename]', '<p>Здравствуйте, [name]!</p>\r\n\r\n<p>Для восстановления доступа к личному кабинету перейдите по ссылке [link]<br />\r\nПосле этого Вам будет предложено изменить пароль доступа.</p>\r\n\r\n<p>Спасибо, что Вы с нами. Ваш [sitename].</p>\r\n', 7),
(4, 'Заказ обратного звонка', 'Заказ обратного звонка на [sitename]', '<p>На сайте [sitename], заказали обратный звонок!</p>\r\n\r\n<p>Имя - [name],<br />\r\nТелефон для связи - [phone],<br />\r\nУдобное время для звонка - [time]</p>\r\n', 10),
(5, 'Форма сбоку', 'Сообщение из формы "Записаться на консультацию"', '<p>Запись на [target] на [sitename]</p>\r\n\r\n<p>Автор сообщения - [name],<br />\r\nКонтакты - [phone]<br />\r\nУдобное время для звонка - [time]<br />\r\n&nbsp;</p>\r\n\r\n<p>Комментарий:<br />\r\n[text]</p>\r\n', 13),
(6, 'Форма заказ услуги', 'Запись на услугу', '<p>Здравствуйте</p>\r\n', 16),
(7, 'Форма запись на событие', 'Запись на событие', '<p>Здравствуйте</p>\r\n', 19),
(8, 'Форма запись к специалисту', 'Запись к специалисту', '<p>Здравствуйте</p>\r\n', 22),
(9, 'Форма заказ сертификата', 'Заказ подарочного сертификата', '<p>Здравствуйте</p>\r\n', 25),
(10, 'Форма заказ товара (админу)', 'Заказ нового товара', '<p>Здравствуйте</p>\r\n', 28),
(11, 'Форма заказ товара (клиенту)', 'Заказ товара на [sitename]', '<p>Здравствуйте, [name]!</p>\r\n\r\n<p>Вы заказали у нас [order]</p>\r\n', 31),
(12, 'Форма заказ тренинга (админу)', 'Заказ нового нового тренинга', '<p><span style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px;">[target] -&nbsp;</span><small style="box-sizing: border-box; font-size: 11.9px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">Цель&nbsp;</small></p>\r\n\r\n<p><span style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px;">[name] -&nbsp;</span><small style="box-sizing: border-box; font-size: 11.9px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">Имя</small><br style="box-sizing: border-box; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px;" />\r\n<span style="font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px;">[phone] -&nbsp;</span><small style="box-sizing: border-box; font-size: 11.9px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;">Телефон</small></p>\r\n', 34),
(13, 'Форма заказ тренинга (клиенту)', 'Заказ тренинга на [sitename]', '<p>Здравствуйте, [name]!</p>\r\n\r\n<p>Вы заказали у нас [order]</p>\r\n', 37),
(14, 'Форма запись на акцию', 'Вы записались на участие в акции', '<p>Здравствуйте! У нас Акция!</p>\r\n', 21),
(15, 'Форма обратной связи на стр. контакты', 'Сообщение из формы "Обратная связь" на [sitename]', '<p>На странице &quot;контакты&quot; в форме обратной связи оставили сообщение:</p>\r\n\r\n<p>Автор сообщения - [name],<br />\r\nКонтакты - [phone]</p>\r\n\r\n<p>Текст сообщения:<br />\r\n[text]</p>\r\n', 43),
(16, 'Форма изменения пароля после процедура восстановления', 'Новые данные для входа на сайт [sitename]', '<p>Здравствуйте, [name]!</p>\r\n\r\n<p>Ваш пароль успешно изменен!</p>\r\n\r\n<p>Ваши данные для входа на сайт:<br />\r\nЛогин - [email]<br />\r\nПароль - [password]</p>\r\n\r\n<p>Спасибо, что Вы с нами. Ваш [sitename].</p>\r\n', 8),
(17, 'Форма запись на акцию', 'Запись на акцию на сайте [sitename]', '<p>Запись на акцию [target] на [sitename]</p>\r\n\r\n<p>Имя &nbsp;- [name],<br />\r\nТелефон - [phone]<br />\r\nУдобное время для звонка - [time]</p>\r\n\r\n<p>Комментарий:<br />\r\n[text]</p>\r\n', 20),
(18, 'Запись на событие для клиента', 'Запись на событие на [sitename]', '<p>Здравствуйте, [name]!<br />\r\nВы успешно записались на событие [order].<br />\r\nс чем мы вас и поздравляем! )<br />\r\n<br />\r\nСпасибо что вы с нами!</p>\r\n', 18),
(19, 'Запись на консультацию', 'Запись на консультацию', '<p>Здравствуйте, [name]!</p>\r\n\r\n<p>Поздравляем, вы успешно записались на консультацию по теме [target]</p>\r\n', 14),
(20, 'Форма запись услуги клиенту.', 'Заказ услуги на [sitename]', '<p>Здравствуйте, [name]!</p>\r\n\r\n<p>Вы заказали услугу [target] на сайте [sitename]</p>\r\n', 17),
(21, 'Форма запись к специалисту клиенту', 'Запись к специалисту на [sitename]', '<p>Здравствуйте, [name].</p>\r\n\r\n<p>Вы записались к специалисту [target]. Наш специалист обязательно найдет время для вас и свяжеться с вами.</p>\r\n', 23),
(22, 'Заказ сертификата клиенту', 'Заказ подарочного сертификата на [sitename]', '<p>Здравствуйте, [name]!</p>\r\n\r\n<p>Вы заказали подарочный сертификат!</p>\r\n', 26);

-- --------------------------------------------------------

--
-- Структура таблицы `fav`
--

CREATE TABLE IF NOT EXISTS `fav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `created_time` int(11) NOT NULL,
  `updated_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `fav`
--

INSERT INTO `fav` (`id`, `user_id`, `created_time`, `updated_time`) VALUES
(1, '1', 1489433147, 1489483566),
(2, 'beaf90466b1a4ac318caf07e99208ec5', 1489735421, 1489735421),
(3, '64f46a1b9400ba72547d2485a6a219cd', 1493098433, 1493098433);

-- --------------------------------------------------------

--
-- Структура таблицы `fav_element`
--

CREATE TABLE IF NOT EXISTS `fav_element` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(55) DEFAULT NULL,
  `model` varchar(110) COLLATE utf8_unicode_ci NOT NULL,
  `fav_id` int(11) NOT NULL,
  `item_id` int(55) NOT NULL,
  `count` int(11) NOT NULL,
  `price` decimal(11,2) DEFAULT NULL,
  `hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fav_id` (`fav_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `feature`
--

CREATE TABLE IF NOT EXISTS `feature` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `content_id` int(10) NOT NULL,
  `module` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `in_filter` int(1) NOT NULL DEFAULT '0',
  `weight` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `feature`
--

INSERT INTO `feature` (`id`, `content_id`, `module`, `name`, `value`, `in_filter`, `weight`) VALUES
(1, 1, 'product', 'Сыпучесть', '100%', 0, 0),
(2, 1, 'product', 'Вязкость', '25', 0, 0),
(3, 1, 'product', 'Масса', '350гр.', 0, 0),
(4, 1, 'product', 'Влажность', '80%', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `file`
--

CREATE TABLE IF NOT EXISTS `file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) unsigned NOT NULL,
  `module` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` int(3) unsigned NOT NULL,
  `delta` int(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `content_id` (`content_id`),
  KEY `module` (`module`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1117 ;

--
-- Дамп данных таблицы `file`
--

INSERT INTO `file` (`id`, `content_id`, `module`, `filename`, `alt`, `title`, `link`, `description`, `type`, `delta`) VALUES
(491, 1, 'main', 'favicon.ico', '', '', '', '', 3, 0),
(515, 1, 'profile', 'DSC_0884.jpg', '', '', '', '', 2, 0),
(887, 1, 'product', 'handsand1000x1000.jpg', 'Песочек', '', '', '', 2, 0),
(888, 1, 'product', '1011697456.jpg', 'Песочный замок', '', '', '', 2, 1),
(1005, 1, 'product', 'pesok.jpg', '', '', '', '', 1, 0),
(1095, 1, 'banner', 'prodvizhenie_salona_krasoty.jpg', '', '', '', '', 1, 0),
(1097, 2, 'banner', '140567685_slide_44.jpg', '', '', '', '', 1, 0),
(1098, 93, 'catalog', 'business1.jpg', '', '', '', '', 1, 0),
(1099, 94, 'catalog', 'business1.jpg', '', '', '', '', 1, 0),
(1100, 95, 'catalog', 'business1.jpg', '', '', '', '', 1, 0),
(1101, 96, 'catalog', 'business1.jpg', '', '', '', '', 1, 0),
(1102, 97, 'catalog', 'business1.jpg', '', '', '', '', 1, 0),
(1103, 98, 'catalog', 'business1.jpg', '', '', '', '', 1, 0),
(1104, 99, 'catalog', 'business1.jpg', '', '', '', '', 1, 0),
(1106, 1, 'payment', 'koshelek.png', '', '', '', '', 1, 0),
(1107, 2, 'payment', 'visa_mastercard.png', '', '', '', '', 1, 0),
(1108, 3, 'payment', 'yad.png', '', '', '', '', 1, 0),
(1109, 1, 'shipping', 'motocurier.png', '', '', '', '', 1, 0),
(1110, 2, 'shipping', 'ui56af90c5d405e456133643.jpg', '', '', '', '', 1, 0),
(1111, 3, 'shipping', 'sdek.jpg', '', '', '', '', 1, 0),
(1112, 1, 'option', '200pxColor_circle_huesat.png', '', '', '', '', 1, 0),
(1113, 2, 'option', '200pxColor_circle_huesat.png', '', '', '', '', 1, 0),
(1114, 3, 'option', '200pxColor_circle_huesat.png', '', '', '', '', 1, 0),
(1115, 4, 'option', '200pxColor_circle_huesat.png', '', '', '', '', 1, 0),
(1116, 5, 'option', '200pxColor_circle_huesat.png', '', '', '', '', 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `filter`
--

CREATE TABLE IF NOT EXISTS `filter` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `infoblock`
--

CREATE TABLE IF NOT EXISTS `infoblock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `infoblock`
--

INSERT INTO `infoblock` (`id`, `title`, `body`, `alias`, `weight`, `status`) VALUES
(2, 'Блок 404', '<p>Скорее всего, ссылка устарела или была изменена. Попробуйте вернуться назад или перейти на <a href="/">главную</a> страницу сайта.</p>\r\n', 'block_404', 0, 1),
(3, 'Адрес в футере', 'Адрес в футере', 'footer_left_block', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `type_id` int(3) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Дамп данных таблицы `menu`
--

INSERT INTO `menu` (`id`, `parent_id`, `type_id`, `title`, `url`, `icon`, `weight`, `status`) VALUES
(1, 0, 0, 'Главная', '/', '', 0, 1),
(13, 0, 0, 'Контакты', '/contacts', '', 5, 1),
(28, 0, 0, 'Каталог', '/cat', '', 1, 1),
(30, 0, 0, 'Товары', '/products', '', 3, 1),
(32, 0, 1, 'Вконтакте', '/', 'vk', 0, 1),
(33, 0, 1, 'Facebook', '/', 'facebook', 1, 1),
(34, 0, 1, 'Инстаграм', '/', 'instagram', 2, 1),
(35, 0, 1, 'Твиттер', '/', 'twitter', 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `option`
--

CREATE TABLE IF NOT EXISTS `option` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `option_type` int(3) NOT NULL,
  `content_id` int(10) NOT NULL,
  `module` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `weight` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `option`
--

INSERT INTO `option` (`id`, `option_type`, `content_id`, `module`, `name`, `code`, `price`, `weight`) VALUES
(1, 1, 1, 'product', 'Красный', 'red', '0.00', 0),
(2, 1, 1, 'product', 'Зеленый', 'green', '0.00', 0),
(3, 1, 1, 'product', 'Синий', 'blue', '0.00', 0),
(4, 2, 1, 'product', 'Большой', 'big', '1500.00', 0),
(5, 2, 1, 'product', 'Средний', 'middle', '0.00', 0),
(6, 2, 1, 'product', 'Маленький', 'little', '800.00', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `date` varchar(255) NOT NULL,
  `status` int(3) NOT NULL,
  `shipping` int(3) NOT NULL,
  `payment` int(3) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Дамп данных таблицы `order`
--

INSERT INTO `order` (`id`, `user_id`, `date`, `status`, `shipping`, `payment`, `name`, `phone`, `email`, `address`, `city`, `type`, `total`, `text`) VALUES
(25, 1, '2017-03-17', 0, 2, 2, 'Админ', '12345', 'dmvolt77@gmail.com', '', '', 'product', '2180.00', 'Тестовый заказ');

-- --------------------------------------------------------

--
-- Структура таблицы `order_product`
--

CREATE TABLE IF NOT EXISTS `order_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `product_option` varchar(255) NOT NULL,
  `product_price` decimal(15,2) NOT NULL,
  `product_qty` int(10) unsigned NOT NULL,
  `product_total` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Дамп данных таблицы `order_product`
--

INSERT INTO `order_product` (`id`, `order_id`, `product_id`, `product_title`, `product_code`, `product_option`, `product_price`, `product_qty`, `product_total`) VALUES
(24, 25, 1, 'Кинетический песок Kinetic Sand', '111', '{"1":{"name":"\\u0426\\u0432\\u0435\\u0442","variants":{"1":"\\u041a\\u0440\\u0430\\u0441\\u043d\\u044b\\u0439","2":"\\u0411\\u0435\\u043b\\u044b\\u0439","3":"\\u0421\\u0438\\u043d\\u0438\\u0439"}},"2":{"name":"\\u0420\\u0430\\u0437\\u043c\\u0435\\u0440","variants":{"4":"XL","5":"X', '1090.00', 2, '2180.00');

-- --------------------------------------------------------

--
-- Структура таблицы `page`
--

CREATE TABLE IF NOT EXISTS `page` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `short_title` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `teaser` text NOT NULL,
  `body` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `page`
--

INSERT INTO `page` (`id`, `short_title`, `title`, `teaser`, `body`, `alias`, `weight`, `status`) VALUES
(4, '', 'Контактная информация', '', '<p><strong>Центр современных психологических технологий &laquo;ИСКУССТВО ЖИТЬ&raquo;</strong></p>\r\n\r\n<p>открыт для вас ежедневно с 10:00 до 21:00 по адресу:<br />\r\nг. Нижний Новгород, площадь Горького,<br />\r\nул. Новая 51 ( 8 этажное здание за магазином &quot;Spar&quot;), 6 этаж</p>\r\n\r\n<div><strong>Наш телефон:</strong></div>\r\n\r\n<p>(831) 291-45-05</p>\r\n\r\n<div><strong>E-mail:</strong></div>\r\n\r\n<p><a href="mailto:iskusstvo.zhit@yandex.ru">iskusstvo.zhit@yandex.ru</a></p>\r\n', 'contacts', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `action` varchar(255) NOT NULL,
  `weight` int(3) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `payment`
--

INSERT INTO `payment` (`id`, `title`, `body`, `action`, `weight`, `status`) VALUES
(1, 'Наличными при получении', '', '', 1, 1),
(2, 'Банковская карта', '', '', 2, 1),
(3, 'Яндекс Деньги', '', '', 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `old_price` decimal(15,2) NOT NULL,
  `teaser` text NOT NULL,
  `body` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `attach_title` varchar(255) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `in_front` int(1) NOT NULL DEFAULT '0',
  `is_not` int(1) NOT NULL DEFAULT '0',
  `is_main` int(1) NOT NULL DEFAULT '0',
  `is_hit` int(1) NOT NULL DEFAULT '0',
  `is_sale` int(1) NOT NULL DEFAULT '0',
  `is_new` int(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id`, `title`, `code`, `sku`, `price`, `old_price`, `teaser`, `body`, `alias`, `attach_title`, `weight`, `in_front`, `is_not`, `is_main`, `is_hit`, `is_sale`, `is_new`, `status`) VALUES
(1, 'Кинетический песок Kinetic Sand', '111', '', '1090.00', '0.00', '<p>Это уникальный материал, который станет любимой игрой вашего ребенка, поможет развить его фантазию, мелкую моторику рук, даст широкие возможности для самовыражения.</p>\r\n', '<p><a href="/services/psihologicheskaya-pomoshch-konsultaciya/detskiy-psiholog">Детские психологи</a> и заботливые мамы, знакомые с таким методом работы, как <a href="/training/pesochnaya-terapiya">песочная терапия</a>, знают, что не всякий материал пригоден для игр ребенка. Сложно представить, что опытный специалист, или мама, тщательно оберегающая малыша от грязи и болезней, принесут для занятия песок с улицы. Поэтому перед ними встает закономерный вопрос &ndash; где купить кинетический песок в Нижнем Новгороде? Он продается в Центре &laquo;Искусство Жить&raquo;.</p>\r\n\r\n<p>Перед покупкой попробуем разобраться, что представляет собой данный материал, как выбрать производителя и в каких объемах его возможно заказать.</p>\r\n', 'kineticheskiy-pesok-Kinetic-Sand', 'Возможно, вас также заинтересует', 0, 0, 1, 0, 1, 0, 1, 1),
(7, 'Основной материал модуля', '', '', '0.00', '0.00', '', '', 'osnovnoy-material-modulya', 'Возможно, вас также заинтересует', 0, 0, 0, 1, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `product_action`
--

CREATE TABLE IF NOT EXISTS `product_action` (
  `parent_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `product_action`
--

INSERT INTO `product_action` (`parent_id`, `child_id`) VALUES
(2, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `product_catalog`
--

CREATE TABLE IF NOT EXISTS `product_catalog` (
  `parent_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `product_product`
--

CREATE TABLE IF NOT EXISTS `product_product` (
  `parent_id` int(10) NOT NULL,
  `child_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `product_product`
--

INSERT INTO `product_product` (`parent_id`, `child_id`) VALUES
(3, 5),
(3, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `phathername` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL,
  `sub` int(1) NOT NULL DEFAULT '0',
  `age` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `profile`
--

INSERT INTO `profile` (`id`, `user_id`, `name`, `lastname`, `phathername`, `phone`, `email`, `sale`, `sub`, `age`) VALUES
(4, 12, 'Дмитрий', 'Хлебов', 'Иванович', '+79130063603', 'dmvolt77@yandex.ru', '', 1, ''),
(6, 1, 'Админ', '', '', '12345', '', '', 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `review`
--

CREATE TABLE IF NOT EXISTS `review` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL DEFAULT '0',
  `short_title` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `teaser` text NOT NULL,
  `body` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '0',
  `is_main` int(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

CREATE TABLE IF NOT EXISTS `seo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(10) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `title_h1` varchar(255) NOT NULL,
  `meta_key` text NOT NULL,
  `meta_desc` text NOT NULL,
  `meta_title2` varchar(255) NOT NULL,
  `title_h12` varchar(255) NOT NULL,
  `meta_key2` text NOT NULL,
  `meta_desc2` text NOT NULL,
  `module` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `content_id` (`content_id`),
  KEY `module` (`module`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=200 ;

--
-- Дамп данных таблицы `seo`
--

INSERT INTO `seo` (`id`, `content_id`, `meta_title`, `title_h1`, `meta_key`, `meta_desc`, `meta_title2`, `title_h12`, `meta_key2`, `meta_desc2`, `module`) VALUES
(2, 1, '', '', '', '', '', '', '', '', 'main'),
(3, 5, 'Щепин Владимир Владиславович — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(11, 40, 'Психологическая помощь в Нижнем Новгороде, консультация психолога и психотерапевта - Искусство Жить', '', 'Психологическая помощь в Нижнем Новгороде, консультация психолога, прием врача-психолога, клинического психолога и психоаналитика. ', 'Консультация психологов различных специализаций, прием психотерапевта, врача-психолога, эффективная психологическая помощь в центре Искусство Жить.', '', '', '', '', 'service'),
(12, 41, 'Тренинги, семинары и мастер-классы в Нижнем Новгороде - Искусство Жить', '', 'тренинги, семинары, мастер-классы в Нижнем Новгороде', 'Тренинги, программы, мастер-классы и семинары нашего Центра рассчитаны на самых разных людей. Мы предлагаем широкий выбор программ взрослым и детям, семейным парам и специалистам.', '', '', '', '', 'service'),
(13, 54, 'Расстановки по Берту Хеллингеру - психологическкий центр Искусство Жить', '', 'системные и семейные расстановки по Берту Хеллингеру', 'В системно-феноменологическом подходе специалист работает с нашим бессознательным, расстановочный процесс помогает избавиться от родовых травм, освободиться от чувства вины, ощутить родительскую любовь. ', '', '', '', '', 'service'),
(14, 43, 'Тренинги и программы для психологов, педагогов и студентов - Искусство Жить', '', 'программы по саморазвитию психолога, психологические тренинги для педагогов и психологов, практика для студентов-психологов\r\n\r\n', 'Важное направление работы Центра – образовательные программы для специалистов: повышение квалификации для психологов и психотерапевтов, студенческая практика, профессиональные психологические тренинги для психологов и педагогов.', '', '', '', '', 'service'),
(15, 55, '', 'Детский и подростковый центр психологии и развития', '', '', '', '', '', '', 'service'),
(16, 59, 'Детский психолог в Нижнем Новгороде - Искусство Жить ', '', 'Детский психолог в Нижнем Новгороде, занятия педагога-психолога с детьми, подготовка детей к школе', 'В нашем Центре вы можете получить консультацию детского психолога по широкому спектру проблем: трудный ребенок, плохая успеваемость, заикание, детская депрессия, аутизм - только часть из них. ', '', '', '', '', 'service'),
(17, 60, 'Подростковый психолог в Нижнем Новгороде - Искусство Жить ', '', 'Подростковый психолог в Нижнем Новгороде, индивидуальные занятия для подростков, помощь родителям с трудными подростками\r\n', 'Подростковый психолог окажет помощь родителям с трудным подростком в семье. В нашем Центре есть как множество полезных занятий для подростков, так и индивидуальные коррекционно-развивающие занятия для ваших чад. \r\n', '', '', '', '', 'service'),
(18, 65, 'Профориентация, профессиональное самоопределение личности - Искусство Жить', '', 'профессиональное самоопределение личности, профориентация учащихся и старшеклассников, профдиагностика, выбор профессии для школьников \r\n', 'Выбор профессии с помощью профессионального самоопределения, повышение квалификации, смена поля деятельности, переподготовка – все это легко осуществимо вместе с психологами центра Искусство Жить.', '', '', '', '', 'service'),
(19, 75, '', '', '', '', '', '', '', '', 'service'),
(25, 1, '', '', '', '', '', '', '', '', 'sert'),
(26, 83, '', '', '', '', '', '', '', '', 'service'),
(27, 66, 'Психологические тренинги и мастер-классы в Нижнем Новгороде - Искусство Жить', '', 'психологические тренинги в Нижнем Новгороде\r\n\r\n', 'Тренинги по психологии нашего Центра - это снятие психоэмоциональных барьеров, мешающих вашему развитию, устранение физических зажимов, расширение зоны собственного психологического комфорта. ', '', '', '', '', 'service'),
(28, 67, 'Творческие тренинги, программы и мастер-классы, арт-терапия в Нижнем Новгороде -  Искусство Жить', 'Творческие тренинги, программы и мастер-классы', 'арт терапия, творческие мастер-классы, тренинги креативности и развития творческих способностей', 'Творческие тренинги и мастер-классы центра Искусство Жить - это программы самых разнообразных тематик, включая рисование и рукоделие. ', '', '', '', '', 'service'),
(29, 68, 'Тренинги и программы для организаций и коллективов - психологический центр Искусство Жить', 'Услуги для организаций', 'тренинги на снятие эмоционального напряжения и стресса, психологический тренинг на расслабление и стрессоустойчивость\r\n\r\n', 'Консультационные услуги для организаций и коллективов, услуги по организации развлекательных мероприятий в компании, психологические тренинги на расслабление и стрессоустойчивость, корпоративные праздники.\r\n', '', '', '', '', 'service'),
(30, 1, 'Гришандина Анна Владимировна — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(31, 2, 'Мурзинская Анна — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(32, 3, 'Мизина Наталья Сергеевна — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(33, 4, 'Костицина Ольга Юрьевна — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(34, 56, 'Решение личных проблем с помощью психолога - Искусство Жить', '', 'Решение личных проблем с помощью психолога', 'Опытные специалисты нашего Центра помогут в решении личных проблем. ', '', '', '', '', 'service'),
(35, 57, 'Решение личностных проблем с помощью психолога - Искусство Жить', '', 'Решение личностных проблем с помощью психолога ', 'С помощью наших специалистов вы решите свои личностные проблемы. ', '', '', '', '', 'service'),
(36, 4, '', '', '', '', '', '', '', '', 'page'),
(37, 6, 'Зубарева Наталья Владимировна — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(42, 1, 'Купить кинетический песок - Психологический центр Искусство Жить', '', 'Купить кинетический песок ', 'Купить кинетический песок ', '', '', '', '', 'product'),
(46, 58, 'Семейный психолог в Нижнем Новгороде - Искусство Жить', '', 'консультация семейного психолога\r\n\r\n', 'Если у вас и ваших близких возникают проблемы в отношениях, поможет консультация семейного психолога в центре «Искусство Жить».', '', '', '', '', 'service'),
(47, 61, 'Решение психосоматических проблем - Искусство Жить', '', 'психосоматические проблемы', 'Решение любых психосоматических проблем в нашем Центре - это реально. К вашим услугам высококвалифицированные специалисты с обширным опытом в данной области. ', '', '', '', '', 'service'),
(48, 62, 'Лечение депрессии - психологический центр Искусство Жить', '', 'анонимное лечение депрессии в Нижнем Новгороде, помощь психолога при депрессии, не медикаментозные методы и лечение антидепрессантами. ', 'Анонимная помощь психолога при депрессии, медикаментозное лечение и психотерапия. Запишитесь на бесплатную предварительную консультацию.  ', '', '', '', '', 'service'),
(49, 63, 'Избавление от зависимостей - Искусство Жить', '', 'лечение зависимостей', '', '', '', '', '', 'service'),
(50, 64, 'Психологическая помощь при эмоциональных травмах и в кризисных ситуациях - Искусство Жить', 'Психологическая помощь при эмоциональных травмах и в кризисных ситуациях', 'психологическая помощь в кризисных ситуациях, лечение психологических травм', 'Для того, чтобы вы не оставались наедине со своей бедой, мы предлагаем вам свою помощь: программу преодоления травмы.', '', '', '', '', 'service'),
(51, 72, 'Тренинги для всех - Искусство Жить', '', '', '', '', '', '', '', 'service'),
(52, 70, '', '', '', '', '', '', '', '', 'service'),
(53, 82, '', '', '', '', '', '', '', '', 'service'),
(54, 73, 'Женские тренинги, программы и мастер-классы - Искусство Жить', '', '', '', '', '', '', '', 'service'),
(55, 74, 'Тренинги и программы для самопознания и развития уверенности в себе, личностного роста - Искусство Жить', 'Тренинги и программы для самопознания и развития', 'тренинги уверенности в себе, тренинги личностного роста и лидерства, тренинг ценностных ориентаций\r\n\r\n\r\n', 'Эффект программ саморазвития похож на эффект консультации с психологом. Так же, как и после разговора со специалистом, вы увидите свою жизненную ситуацию со стороны, поймете, в каком направлении двигаться дальше, осознаете причины проблем.', '', '', '', '', 'service'),
(56, 76, 'Тренинги и мастер-классы по рисованию - психологический центр Искусство Жить', '', 'Тренинги и мастер-классы по рисованию', '', '', '', '', '', 'service'),
(57, 77, 'Мастер-классы по рукоделию - психологический центр Искусство Жить', '', 'Мастер-классы по рукоделию', '', '', '', '', '', 'service'),
(59, 79, '', '', '', '', '', '', '', '', 'service'),
(71, 71, '', '', '', '', '', '', '', '', 'service'),
(72, 86, '', '', '', '', '', '', '', '', 'service'),
(73, 85, '', '', '', '', '', '', '', '', 'service'),
(74, 87, '', '', '', '', '', '', '', '', 'service'),
(83, 10, 'Выбор тренингов, программ и мастер-классов по свойствам - Исскусство Жить', 'Выбор тренингов, программ и мастер-классов по свойствам', '', '', '', '', '', '', 'training'),
(84, 8, 'Наши события - Психологический центр Искусство Жить', 'Анонс событий ', 'события', 'Описание событий', 'Архив событий - Психологический центр Искусство Жить', 'Архив событий ', 'прошедшие события', 'Описание архивных событий', 'event'),
(85, 1, 'Расписание и цены центра', 'Расписание и цены', 'Ключевые слова, расписание, цены', 'Тут вы можете найти разные цены и расписания, да и вобще, чего тут только нет ..', '', '', '', '', 'plan'),
(88, 89, 'Каталог Услуг', 'Каталог Услуг ', '', '', '', '', '', '', 'service'),
(89, 19, 'Горячие темы центра', 'Горячие темы', 'Горячие темы центра', 'Горячие темы центра', '', '', '', '', 'article'),
(90, 3, 'Акции психологического центра Исскусство Жить', 'Акции', 'акции центра', 'акции нашего центра', '', '', '', '', 'action'),
(91, 7, 'Товары мета тайтл', '', '', '', '', '', '', '', 'product'),
(92, 2, 'Подарочные сертификаты центра', 'Подарочные сертификаты', 'Подарочные сертификаты центра', 'Подарочные сертификаты центра', '', '', '', '', 'sert'),
(93, 7, 'Специалисты психологического центра Исскусство Жить', 'Специалисты ', 'Специалисты психологического центра Исскусство Жить', 'Специалисты психологического центра Исскусство Жить', '', '', '', '', 'team'),
(94, 11, 'Тренинг Терапевтическая уборка — Искусство Жить', '', 'Тренинг Терапевтическая уборка', 'Тренинг Терапевтическая уборка', '', '', '', '', 'training'),
(95, 12, 'Чайные медитации «Путь Чая» — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(96, 90, '', '', '', '', '', '', '', '', 'service'),
(103, 13, 'Тренинг «Тайны женской силы» — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(104, 14, 'Тренинг «Дерево Жизни или Дерево исполнения желаний» — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(106, 16, 'Программы снижения веса — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(107, 69, 'Обучение специалистов - психологический центр Искусство Жить', '', '', '', '', '', '', '', 'service'),
(108, 15, 'Обучающая программа по песочной терапии ', '', '', '', '', '', '', '', 'event'),
(110, 17, 'Программа  «Другая и Прежняя» — Искусство Жить', '', '', '', '', '', '', '', 'event'),
(111, 17, 'Метафорические карты как инструмент для работы с подсознанием — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(112, 18, 'Волшебный новогодний тренинг для взрослых — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(113, 19, 'Психологическая настольная игра «Трансформация» — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(114, 20, '', '', '', '', '', '', '', '', 'training'),
(115, 21, 'Трансформационная игра «Лила Чакра» — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(116, 22, 'Тренинг самопознания « За гранью суеты…» — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(118, 23, '', '', '', '', '', '', '', '', 'training'),
(119, 18, 'ПервоКЛАССные каникулы «Умные движения» — Искусство Жить', '', '', '', '', '', '', '', 'event'),
(124, 26, '', '', '', '', '', '', '', '', 'training'),
(125, 21, 'Мастер-класс ЭБРУ-сказка — Искусство Жить', '', '', '', '', '', '', '', 'event'),
(126, 22, 'Авторская программа «Цветные Эбру размышления» — Искусство Жить', '', '', '', '', '', '', '', 'event'),
(127, 27, 'Приключенческие выходные — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(128, 23, 'Тренинг правополушарного рисования для детей — Искусство Жить', '', '', '', '', '', '', '', 'event'),
(129, 28, '«Ночь приключений в Центре» Антистрессовая программа — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(138, 29, '', '', '', '', '', '', '', '', 'training'),
(139, 30, '', '', '', '', '', '', '', '', 'training'),
(140, 32, 'Семейные системные расстановки (обучение) — Искусство Жить', '', '', '', '', '', '', '', 'event'),
(141, 33, 'Программа обучения и практики «Песочная терапия в экзистенциальном подходе» — Искусство Жить', '', '', '', '', '', '', '', 'event'),
(142, 31, '', '', '', '', '', '', '', '', 'training'),
(144, 33, '', '', '', '', '', '', '', '', 'training'),
(145, 34, '', '', '', '', '', '', '', '', 'training'),
(146, 35, '', '', '', '', '', '', '', '', 'training'),
(147, 36, '', '', '', '', '', '', '', '', 'training'),
(148, 91, 'Тренинги по детской безопасности — Искусство Жить', '', '', '', '', '', '', '', 'service'),
(149, 37, 'Защита от похитителя — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(150, 38, 'Девочки в безопасности (13-17 лет) — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(151, 39, 'Защита от неприятностей (13-17 лет) — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(152, 40, 'Безопасный интернет (9-16 лет) — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(153, 41, '', '', '', '', '', '', '', '', 'training'),
(154, 42, 'Развивающая группа для детей и подростков «Секреты общения» — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(155, 43, '', '', '', '', '', '', '', '', 'training'),
(156, 44, '', '', '', '', '', '', '', '', 'training'),
(157, 45, '', '', '', '', '', '', '', '', 'training'),
(158, 46, '', '', '', '', '', '', '', '', 'training'),
(168, 47, '', '', '', '', '', '', '', '', 'training'),
(169, 48, '', '', '', '', '', '', '', '', 'training'),
(170, 49, '', '', '', '', '', '', '', '', 'training'),
(171, 50, '', '', '', '', '', '', '', '', 'training'),
(175, 51, '', '', '', '', '', '', '', '', 'training'),
(176, 8, 'Сазонова Ольга Викторовна — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(177, 9, 'Слепанова Наталья Владимировна — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(178, 10, 'Кумпан Янис Николаевич — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(180, 12, 'Загладина Наталья Владимировна — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(181, 13, 'Окладнова Александра Николаевна — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(182, 14, 'Липовская Людмила — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(183, 15, 'Семонюк Анастасия Александровна — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(184, 16, 'Андреева Наталья — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(185, 17, 'Копытин Александр Иванович — Искусство Жить', '', '', '', '', '', '', '', 'team'),
(186, 52, 'Интегративная травматерапия — Искусство Жить', '', '', '', '', '', '', '', 'training'),
(187, 92, '', '', '', '', '', '', '', '', 'service'),
(188, 53, '', '', '', '', '', '', '', '', 'training'),
(189, 34, 'Расстановочный семинар «Разговор на языке тела: О чем «кричат» симптомы» — Искусство Жить', '', '', '', '', '', '', '', 'event'),
(190, 35, 'Расстановочный семинар Архетипы богинь в жизни — Искусство Жить', '', '', '', '', '', '', '', 'event'),
(191, 98, '', '', '', '', '', '', '', '', 'catalog'),
(192, 99, '', '', '', '', '', '', '', '', 'catalog'),
(195, 93, '', '', '', '', '', '', '', '', 'catalog'),
(196, 94, '', '', '', '', '', '', '', '', 'catalog'),
(197, 95, '', '', '', '', '', '', '', '', 'catalog'),
(198, 96, '', '', '', '', '', '', '', '', 'catalog'),
(199, 97, '', '', '', '', '', '', '', '', 'catalog');

-- --------------------------------------------------------

--
-- Структура таблицы `setting`
--

CREATE TABLE IF NOT EXISTS `setting` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `module` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `setting`
--

INSERT INTO `setting` (`id`, `name`, `value`, `module`) VALUES
(1, 'smtp_host', 'smtp.gmail.com', 'main'),
(2, 'smtp_username', 'info@vadim-design.ru', 'main'),
(3, 'smtp_password', 'Pudd1c0mbe71', 'main'),
(4, 'smtp_port', '465', 'main'),
(6, 'smtp_encryption', 'ssl', 'main');

-- --------------------------------------------------------

--
-- Структура таблицы `shipping`
--

CREATE TABLE IF NOT EXISTS `shipping` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `action` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `weight` int(3) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `shipping`
--

INSERT INTO `shipping` (`id`, `title`, `body`, `action`, `price`, `weight`, `status`) VALUES
(1, 'Самовывоз', '<p>Необходимо приехать на склад и забрать товар самостоятельно по адресу ...</p>', '', '0', 1, 1),
(2, 'Почта России', '<p>Ну сами понимаете ...</p>', '', '500', 2, 1),
(3, 'СДЭК', '<p>Быстро в течении 3 - 4 дней.</p>', '', '800', 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `siteinfo`
--

CREATE TABLE IF NOT EXISTS `siteinfo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `map` text NOT NULL,
  `counter` text NOT NULL,
  `copyright` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `siteinfo`
--

INSERT INTO `siteinfo` (`id`, `title`, `email`, `phone`, `address`, `slogan`, `body`, `map`, `counter`, `copyright`) VALUES
(1, 'Интернет Магазин', 'dmvolt77@gmail.com', '+7 (222) 222-33-55', '<p>Новосибирск<br />\r\nул. Новая 51</p>\r\n', 'Интернет Магазин', '<p>Наш интернет магазин может продавать все что угодно!</p>\r\n', '', '', 'Интернет Магазин');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `auth_key` varchar(32) DEFAULT NULL,
  `email_confirm_token` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `data` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `status` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `created_at`, `updated_at`, `username`, `auth_key`, `email_confirm_token`, `password_hash`, `password_reset_token`, `email`, `data`, `role`, `status`) VALUES
(1, 1460541709, 1484734076, 'admin', 'QOW_cwrgowqT4m0mo8a3QKaCH5z5RT3b', NULL, '$2y$13$JCJUoZ.5yJUl8Rgf/POVK.lMXUAHmJUhvk3aCZ0d1b374LczL.TxW', NULL, 'dmvolt77@gmail.com', NULL, 'admin', 1),
(12, 1477992396, 1484819509, 'dmvolt77@yandex.ru', '6rMfWRmCi0qlqP89PAl9nZX1UTCQbZNM', NULL, '$2y$13$KmvHnaGBY/ORdCbRyG.9se.L8Xqxxt/ja1r9SUbqW1z9N2rzUU7gG', NULL, 'dmvolt77@yandex.ru', NULL, 'user', 1);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `cart_element`
--
ALTER TABLE `cart_element`
  ADD CONSTRAINT `elem_to_cart` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `fav_element`
--
ALTER TABLE `fav_element`
  ADD CONSTRAINT `elem_to_fav` FOREIGN KEY (`fav_id`) REFERENCES `fav` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
